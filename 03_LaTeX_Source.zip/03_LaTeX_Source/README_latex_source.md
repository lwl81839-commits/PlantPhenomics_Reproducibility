LaTeX Source for Plant Phenomics Submission

This folder contains the clean non-anonymized LaTeX source for:

Stage-routed workflow for fixed-view RGB maize growth phenotyping

Compile with:

```powershell
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Included files:

- `main.tex`: main LaTeX entry file
- `abstract.tex`: abstract text
- `keywords.tex`: keyword list
- `body.tex`: article body, declarations, data/code availability, and supplementary-material list
- `references.bib`: bibliography database
- `figures/`: PDF figure files used by `main.tex`

The source is non-anonymized and matches the manuscript PDF prepared for the 2026-06-25 Plant Phenomics submission package. This version includes Supplementary File S3c as a same-view ruler-anchored endpoint-consistency check and aligns the manuscript-level supplementary-file labels with the separated data, result, code and archive folders used for upload.
